# Hillstrom (2008) — Email Marketing Challenge

A real online retailer ran a small clean RCT in 2008: 64,000 customers were
**randomly assigned** to receive a men's-merchandise email, a women's-merchandise
email, or no email. Visits, purchases, and spending in the next two weeks were
recorded. Because assignment was random, this is a textbook RCT.

```
1_Hillstrom_Email/
├── Hillstrom.csv                   64,000 real customers — raw, no Stata needed
├── hillstrom_data_dictionary.md    variables + how to build got_email
└── Hillstrom_2008.pdf              the original challenge writeup
```

**Start with `Hillstrom.csv` and read `hillstrom_data_dictionary.md`.** That's your
dataset for the assignment — **real customers, real assignment** (not simulated),
ready to load in your Python notebook.

## You build the treatment column yourself
The file has a `segment` column (`"Mens E-Mail"` / `"Womens E-Mail"` / `"No E-Mail"`)
but no treatment indicator. As Task 1 instructs, create one:

```python
df["got_email"] = (df["segment"] != "No E-Mail").astype(int)
```

Then estimate `conversion ~ got_email`. The difference in mean `conversion`
between the two groups is the headline — about **+0.5 percentage points**, or
roughly a doubling off a small base (≈ 1.07% vs 0.57%).

## About the source
Hillstrom (2008) is a **public industry data-mining challenge**, not a
peer-reviewed journal paper — the included `Hillstrom_2008.pdf` is the original
blog write-up. You won't be chasing a published coefficient here; the "right"
answer is whatever the clean randomized comparison gives. You're graded on
running and interpreting the comparison correctly.
