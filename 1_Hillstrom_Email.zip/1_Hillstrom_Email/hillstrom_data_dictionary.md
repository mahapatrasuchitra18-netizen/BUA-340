# Hillstrom (2008) Email Marketing — Data Dictionary

## What's in this folder
- **`Hillstrom.csv`** — the real MineThatData email-marketing experiment: 64,000 customers, 12 columns. This is real data, not simulated.
- This dictionary.

## The experiment
In 2008 an online retailer randomly sent each customer one of three things: a men's-merchandise email, a women's-merchandise email, or no email. Visits, purchases, and spending over the next two weeks were recorded. Because the email was assigned at random, this is a clean randomized controlled trial (RCT).

## Source
Kevin Hillstrom, "The MineThatData E-Mail Analytics and Data Mining Challenge" (2008).
Direct CSV: http://www.minethatdata.com/Kevin_Hillstrom_MineThatData_E-MailAnalytics_DataMiningChallenge_2008.03.20.csv

## You will create the treatment column yourself
The file has a `segment` column with three values but **no treatment indicator**. As Task 1 says, make one:
- `got_email = 1` if `segment` is `"Mens E-Mail"` or `"Womens E-Mail"`
- `got_email = 0` if `segment` is `"No E-Mail"`

## Variables

| Variable | Type | Description |
|---|---|---|
| `recency` | integer | Months since the customer's last purchase. |
| `history_segment` | text | Categorical band of prior-year spend, e.g. `"2) $100 - $200"`. |
| `history` | dollars | Actual dollars spent in the prior year. |
| `mens` | 0/1 | 1 = bought men's merchandise in the prior year. |
| `womens` | 0/1 | 1 = bought women's merchandise in the prior year. |
| `zip_code` | text | `Urban` / `Suburban` / `Rural` (spelled `Surburban` in the file). |
| `newbie` | 0/1 | 1 = new customer in the last 12 months. |
| `channel` | text | Prior-year purchase channel: `Phone` / `Web` / `Multichannel`. |
| `segment` | text | **Treatment arm:** `"Mens E-Mail"`, `"Womens E-Mail"`, or `"No E-Mail"`. Use this to build `got_email`. |
| `visit` | 0/1 | 1 = visited the website in the two weeks after the campaign. |
| `conversion` | 0/1 | **Primary outcome:** 1 = made a purchase. |
| `spend` | dollars | Amount spent in the two weeks after the campaign. |

Unit of observation: one customer. Sample size: 64,000 (about 21,300 in each of the three arms).

## Task 1 headline
Regress `conversion` on `got_email`. The headline is the difference in mean `conversion` between the email and no-email groups — about **+0.5 percentage points** (≈ 1.07% vs 0.57%), i.e. email roughly doubles the conversion rate off a low base.

## Common pitfalls
- This is a teaching dataset, not a published paper — the "headline" is simply the email-vs-no-email difference in `conversion`, not a paper coefficient.
- `conversion` is rare (~0.9%). Keep all 64,000 rows; don't subsample down to a few hundred or you'll have almost no purchases left to measure.
- For the matching task (Task 3), match on customer characteristics like `recency`, `history`, `mens`, `womens`. Because assignment really was random, matching should roughly recover the experimental answer.
